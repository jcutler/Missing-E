Super Mono Icons (Designed by Jack Cai)

Copyright (C) 2010 Double-J Design. All rights reserved.
The icons are licensed under a Creative Commons Attribution
3.0 license. <http://creativecommons.org/licenses/by/3.0/>

If you can't or don't want to provide a link back, please
purchase a royalty-free license.
<http://www.doublejdesign.co.uk/>

As if you need the icons in your own colour, please contact 
me with your colour code.
<mailto:info@doublejdesign.co.uk>

------------------------------------------------------------

Super Mono Icon Set includes:

--Super Mono Basic (in 4 colours)
----Blue
----Green
----Red
----Yellow

--Super Mono Reflection (in 4 colours)
----Blue
----Green
----Red
----Yellow

--Super Mono Sticker (in 1 colour)
